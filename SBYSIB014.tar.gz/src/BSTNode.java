
/**
 * 
 * Binary Search Tree implementation adapted from Hussein Suleman (2017)
 * Original implementation date: 26 March 2017
 * Modified to include statement confidence scores and update functionality
 * 
 * Represents a node in a Binary Search Tree (BST) that stores a {@code Statement}.
 * Each node contains a reference to its left and right child nodes.
 * 
 * @author Modified by Sibongokuhle Sibiya(SBYSIB014)
 *
 * @since 2025-03-15
 */

public class BSTNode {

    /** The statement stored in this node. */
    public Statement data; 

    /** The left child node in the BST. */
    public BSTNode left;

    /** The right child node in the BST. */
    public BSTNode right;

    /**
     * Constructs a new {@code BSTNode} with the given statement.
     * Initially, the left and right children are set to {@code null}.
     *
     * @param data The statement to be stored in the node.
     * @param left The left child of this node (unused in constructor).
     * @param right The right child of this node (unused in constructor).
     */

    public BSTNode(Statement data, BSTNode left, BSTNode right) {

        this.data = data;
        this.left = null;
        this.right = null;
    }

    /**
     * Retrieves the statement stored in this node.
     *
     * @return The {@code Statement} stored in the node.
     */

    public Statement getStatement() {

        return data;
    }

    /**
     * Retrieves the left child of this node.
     *
     * @return The left child node, or {@code null} if none exists.
     */

    public BSTNode getLeft() {

        return left;
    }

    /**
     * Retrieves the right child of this node.
     *
     * @return The right child node, or {@code null} if none exists.
     */

    public BSTNode getRight() {

        return right;
    }
}
        
    