
/**
 * The entry point for the knowledge base application using a Binary Search Tree (BST) implementation.
 * 
 * <p>This class initializes an instance of {@code GenericsKbBSTApp} and displays the menu 
 * for interacting with the knowledge base.</p>
 * 
 * @author Sibongokuhle Sibiya
 * @version 1.0
 * @since 2025-03-15
 */

public class MainBST {

    /**
     * Default constructor for the MainBST class.
     */
    public MainBST() {

    }

    /**
     * The main method to start the BST program.
     *
     * @param args Command-line arguments
     */

    public static void main(String[] args) {
        
        GenericsKbBSTApp bst = new GenericsKbBSTApp();
        bst.displayMenu();
    }
}