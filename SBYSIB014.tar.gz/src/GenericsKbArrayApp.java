
/**Program to represent a knowledge base using an Array.
 * It allows loading statements from a file, insert statements,
 * search for statements by term, and search by term and sentence.
 *
 * @author Sibongokuhle Sibiya (SBYSIB014)
 * 
 * @since 04 March 2025
 */


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * A class that represents a knowledge base using an array implementation.
 * It allows loading statements from a file, searching for statements by term,
 * updating statements, and displaying user interaction options.
 */

public class GenericsKbArrayApp {
    
    Statement[] statements;
    int size;

    /**
     * Constructs a knowledge base with a given capacity.
     * 
     * @param capacity The maximum number of statements the knowledge base can hold.
     */
    
    public GenericsKbArrayApp(int capacity) {
        
        this.statements = new Statement[capacity];
        this.size = 0;
    }

    /**
     * Loads statements from a file into the knowledge base.
     * 
     * @param fileName The name of the file to read statements from.
     */
    
    public void loadFromFile(String fileName) {
        
        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
        
           String line;
        
           while((line = reader.readLine()) != null && size < statements.length) {
               
               String[] parts = line.split("\t");
               
               String term = parts[0];
               String sentence = parts[1];
               double confidenceScore  = Double.parseDouble(parts[2]);
               
               statements[size] = new Statement(term, sentence, confidenceScore);
               size++;
           }
           System.out.println("Knowledge base loaded successfully.");
           
        }
        catch(IOException e) {
           System.out.println("Knowledge base not found!");
        }
        
    }

    /**
     * Searches for a statement by term.
     * 
     * @param term The term to search for.
     * @return The statement found, or null if no match is found.
     */
        
    public Statement searchByTerm(String term) {
            
        for(int i = 0; i < statements.length; i++) {
            if (statements[i].getTerm().equalsIgnoreCase(term)) {
                  
                return statements[i];
            }
        }
        return null;
         
    }

    /**
     * Searches for a statement by both term and sentence.
     * 
     * @param term The term to search for.
     * @param sentence The sentence to search for.
     * @return The confidence score if found, otherwise -1.
     */
        
    public double searchByTermAndSentence(String term, String sentence) {
          
          for(int i = 0; i < statements.length; i++) {
             if(statements[i].getTerm().equalsIgnoreCase(term) && statements[i].getSentence().equalsIgnoreCase(sentence)) {
               
                return statements[i].getConfidenceScore();
             }
          }
          
          return -1.0;  
            
    }

    /**
     * Updates an existing statement if the new confidence score is higher.
     * 
     * @param term The term associated with the statement.
     * @param sentence The sentence associated with the statement.
     * @param confidenceScore The new confidence score.
     */
        
    public void UpdateStatement(String term, String sentence, double confidenceScore) {
        
        for(int i = 0; i < statements.length; i++) {
           if(statements[i].getTerm().equalsIgnoreCase(term) && statements[i].getConfidenceScore() < confidenceScore) {
             
              statements[i].update(sentence, confidenceScore);
              return;
           }
        }
        System.out.println();
        System.out.println("Statement could not be updated due to lower confidence score.");
        
        
    }

    /**
     * Displays a menu for user interaction and handles user input.
     */
        
    public void displayInfo() {
        
        Scanner scanner = new Scanner(System.in);
        
        while(true) {
            
            System.out.println("Choose an action from the menu.");
            System.out.println("1. Load a knowledge base from a file");
            System.out.println("2. Add a new statement to the knowledge base");
            System.out.println("3. Search for a statement in the knowledge base by term");
            System.out.println("4. Search for a statement in the knowledge base by term and sentence");
            System.out.println("5. Quit");
            
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            
            scanner.nextLine();
            
            if(choice == 1) {
               
               System.out.println();
               
               System.out.print("Enter file name: ");
               String fileName = scanner.nextLine();
               
               System.out.println();
               
               loadFromFile(fileName);
               
               
            }
            else if(choice == 2) {

               System.out.println();
               
               System.out.print("Enter term: ");
               String term = scanner.nextLine();

               System.out.print("Enter the statement: ");
               String sentence = scanner.nextLine();

               System.out.print("Enter the confidence score: ");
               double confidenceScore = scanner.nextDouble();

               UpdateStatement(term, sentence, confidenceScore);
            }
            else if(choice == 3) {

                System.out.println();

                System.out.print("Enter the term: ");
                String term = scanner.nextLine();

                Statement result = searchByTerm(term);
                
                System.out.println();
                
                if(result != null) {
                    System.out.println(result.toString());
                }
                else {
                    System.out.println("Statement not found for the term " + term + ".");
                }
                

            }
            else if(choice == 4) {

                System.out.println();

                System.out.print("Enter the term: ");
                String term = scanner.nextLine();

                System.out.print("Enter the statement to search for: ");
                String sentence = scanner.nextLine();

                System.out.println();

                System.out.println("The statement was found and has a confidence interval of " + searchByTermAndSentence(term, sentence) + ".");
            }
            else {
                System.out.println();
                System.out.println("Application closed.");
                System.exit(0);
            }
            System.out.println();
        }
    }
}