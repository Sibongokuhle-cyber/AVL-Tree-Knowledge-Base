
/**
 * Binary Search Tree implementation adapted from Hussein Suleman (2017)
 * Original implementation date: 26 March 2017
 * Modified to include statement confidence scores and update functionality
 * 
 * Program to represent a knowledge base using a Binary Search Tree.
 * It allows loading statements from a file, insert statements,
 * search for statements by term, and search by term and sentence.
 * 
 * 
 * @author Modified by Sibongokuhle Sibiya (SBYSIB014)
 * 
 * @since 04 March 2025
 */



import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Scanner;

/**
 * A class that represents a knowledge base using a Binary Search Tree (BST).
 * It allows loading statements from a file, inserting statements,
 * searching for statements by term, and searching by term and sentence.
 */

public class GenericsKbBSTApp {

    /** The root node of the BST. */
    public BSTNode root;

/**
     * Constructs an empty knowledge base BST.
     */

    public GenericsKbBSTApp() {

        this.root = null;

    }

    /**
     * Loads statements from a file into the BST.
     *
     * @param fileName The name of the file to read statements from.
     */

    public void loadFromFile(String fileName) {

        try(BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            
            String line;
            while((line = reader.readLine()) != null) {

                String[] parts = line.split("\t");
                
                String term = parts[0];
                String sentence = parts[1];
                double confidenceScore = Double.parseDouble(parts[2]);

                insert(new Statement(term, sentence, confidenceScore));
            }
            System.out.println("Knowledge base added successfully.");
        } 
        catch (Exception e) {
            System.out.println("Knowledge base not found try to enter a file in same directory!");;
        }

    }

    /**
     * Inserts a statement into the BST.
     *
     * @param data The statement to be inserted.
     */

    public void insert(Statement data) {

        if(root == null) {
            root = new BSTNode(data, null, null);

        }
        else {
            insert(data, root);

        }

        
    }

    /**
     * Recursively inserts a statement into the BST.
     *
     * @param data The statement to be inserted.
     * @param node The current node in the BST.
     */

    public void insert(Statement data, BSTNode node) {

        if(data.compareTo(node.getStatement()) < 0) {
            if(node.getLeft() == null) {
                
                node.left = new BSTNode(data, null, null);
            }
            else {
                insert(data, node.getLeft());
            }
        }
        else if(data.compareTo(node.getStatement()) > 0){
            if(node.getRight() == null) {

                node.right = new BSTNode(data, null, null);
            }
            else{
                insert(data, node.right);
            }
        }
        else {
            node.getStatement().update(data.getSentence(), data.getConfidenceScore());
            
            //System.out.println();

            //System.out.println("Statement for term " + data.getTerm() + " has been updated.");
        }


    }

    /**
     * Searches for a statement by term in the BST.
     *
     * @param term The term to search for.
     * @return The statement found, or null if no match is found.
     */

    public Statement searchByTerm(String term) {
         
        if(root == null) {
            return null;
        }
        else {
            return searchByTerm(term, root);
        }

    }

    /**
     * Recursively searches for a statement by term in the BST.
     *
     * @param term The term to search for.
     * @param node The current node in the BST.
     * @return The statement found, or null if no match is found.
     */

    private Statement searchByTerm(String term, BSTNode node) {

        int cmp = term.compareTo(node.getStatement().getTerm());

        if(cmp == 0) {
            return node.getStatement();
        }
        else if (cmp < 0) {
            return (node.left == null) ? null : searchByTerm(term, node.getLeft());
        }
        else {
            return (node.right == null) ? null : searchByTerm(term, node.getRight());
        }
    }

    /**
     * Searches for a statement by both term and sentence in the BST.
     *
     * @param term The term to search for.
     * @param sentence The sentence to search for.
     * @param node The current node in the BST.
     * @return The confidence score if found, otherwise -1.
     */

    public double searchByTermAndStatement(String term, String sentence, BSTNode node) {

        if(node == null) {
            return -1.0;
        }

        int cmp = term.compareTo(node.getStatement().getTerm());

        if(cmp < 0) {
            return searchByTermAndStatement(term, sentence, node.getLeft());
        }
        else if(cmp > 0) {
            return searchByTermAndStatement(term, sentence, node.getRight());
        }
        else {
            return (node.getStatement().getSentence().equalsIgnoreCase(sentence)) ? node.getStatement().getConfidenceScore() : -1.0;
        }
    }

    
    /**
     * Displays the menu for user interaction.
     */
    public void displayMenu() {

        Scanner scanner = new Scanner(System.in);
        
        while(true) {
            
            System.out.println("Choose an action from the menu.");
            System.out.println("1. Load a knowledge base from a file");
            System.out.println("2. Add a new statement to the knowledge base");
            System.out.println("3. Search for a statement in the knowledge base by term");
            System.out.println("4. Search for a statement in the knowledge base by term and sentence");
            System.out.println("5. Quit");
            
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            
            scanner.nextLine();
            
            if(choice == 1) {
               
               System.out.println();
               
               System.out.print("Enter file name: ");
               String fileName = scanner.nextLine();
               
               System.out.println();
               
               loadFromFile(fileName);
               
               //System.out.println();
           }
           
           else if(choice == 2) {

                System.out.println();

                System.out.print("Enter the term: ");
                String term = scanner.nextLine();

                System.out.print("Enter the statement: ");
                String sentence = scanner.nextLine();

                System.out.print("Enter the confidence score: ");
                double confidenceScore = scanner.nextDouble();

                Statement newStatement = new Statement(term, sentence, confidenceScore);

                insert(newStatement);

                //System.out.println();
           }
           
           else if(choice == 3) {

                System.out.println();

                System.out.print("Enter the term to search: ");
                String term = scanner.nextLine();
                
                Statement result = searchByTerm(term);
                
                System.out.println();
                
                if(result != null) {
                    System.out.println(result.toString());
                }
                else {
                    System.out.println("Statement not found for the term " + term + ".");
                }

                //System.out.println();
           }
           else if(choice == 4) {

                System.out.println();

                System.out.print("Enter the term: ");
                String term = scanner.nextLine();

                System.out.print("Enter the statement to search for: ");
                String sentence = scanner.nextLine();

                System.out.println();

                System.out.println("The statement was found with the confidence score of " + searchByTermAndStatement(term, sentence, root));

                //System.out.println();
           }
           else {
                System.out.println();
                System.out.println("Application closed.");
                break;
           }
           System.out.println();
           
        }
        
    }
}