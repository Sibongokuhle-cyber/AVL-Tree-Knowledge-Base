/**
 * A program that creates and manages a knowledge base consisting of terms, sentences, 
 * and confidence scores. The knowledge base allows querying and updating statements.
 * 
 * <p>This program supports storing statements with an associated confidence score, 
 * which represents the certainty of the statement.</p>
 *
 * @author Sibongokuhle Sibiya (SBYSIB014)
 * 
 * @since 04 March 2025
 */


public class Statement implements Comparable<Statement>{
    
    /** The term associated with the statement. */
    public String term;

    /** The actual sentence of the statement. */
    public String sentence;

    /** The confidence score of the statement. */
    public double confidenceScore;

    /**
     * Constructs a new {@code Statement} with the given term, sentence, and confidence score.
     *
     * @param term            The term associated with this statement.
     * @param sentence        The descriptive sentence for the term.
     * @param confidenceScore The confidence score of the statement.
     */
    
    public Statement(String term, String sentence, double confidenceScore) {
        
        this.term = term;
        this.sentence = sentence;
        this.confidenceScore = confidenceScore;
    }

    /**
     * Retrieves the term of this statement.
     *
     * @return The term associated with this statement.
     */
    
    public String getTerm() {
        
        return term;
    }

    /**
     * Retrieves the sentence describing the term.
     *
     * @return The sentence of this statement.
     */
    
    public String getSentence() {
        
        return sentence;
    }

    /**
     * Retrieves the confidence score of the statement.
     *
     * @return The confidence score of this statement.
     */
    
    public double getConfidenceScore() {
        
        return confidenceScore;
    }

    /**
     * Updates the statement with a new sentence and confidence score 
     * if the new confidence score is higher than the current one.
     *
     * @param newSentence        The updated sentence.
     * @param newConfidenceScore The updated confidence score.
     */
    
    public void update(String newSentence, double newConfidenceScore) {
        
        if(newConfidenceScore > this.confidenceScore) {
          
          this.sentence = newSentence;
          this.confidenceScore = newConfidenceScore;
        }

        System.out.println();

        System.out.println("Statement for the term " + term + " has been updated."); 
    }

    /**
     * Compares this statement with another statement based on the term.
     *
     * @param other The other statement to compare to.
     * @return A negative integer, zero, or a positive integer as this term 
     *         is less than, equal to, or greater than the specified term.
     */

    public int compareTo(Statement other) {

        return term.compareTo(other.getTerm());
    }

    /**
     * Returns a string representation of the statement, including the sentence 
     * and its confidence score.
     *
     * @return A string representation of this statement.
     */
    
    public String toString() {
        
        return "Statement found: " + sentence + " " + "(Confidence Score: " + confidenceScore + ")" ;
    }
}