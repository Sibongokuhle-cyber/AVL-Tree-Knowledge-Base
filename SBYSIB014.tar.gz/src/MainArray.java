
/**
 * The entry point of the program, responsible for initializing and executing 
 * the knowledge base application using an array-based implementation.
 * 
 * <p>This class creates an instance of {@code GenericsKbArrayApp} with a 
 * specified capacity and calls the {@code displayInfo} method to show 
 * information about the knowledge base.</p>
 * 
 * @author Sibongokuhle Sibiya
 * 
 * @since 2025-03-15
 */

public class MainArray {
    
    /**
     * Default constructor for the Main class.
     */
    public MainArray() {
        
    }
    
    /**
     * The main method to start the program.
     *
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        
        GenericsKbArrayApp arr_app = new GenericsKbArrayApp(50000);
        
        arr_app.displayInfo();

    }
}